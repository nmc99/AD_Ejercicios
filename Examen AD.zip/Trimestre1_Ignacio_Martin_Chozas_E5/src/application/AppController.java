package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Optional;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextArea;

public class AppController {

	public TextArea textarea;

	public void contenido() {
		
		System.out.println("MOSTRAR");
		try {
			File archivo = new File ("archivo.txt");
			FileReader fr;
			fr = new FileReader (archivo);
			BufferedReader br = new BufferedReader(fr);
			String linea = br.readLine();
			String contenido = "";
			while ((linea = br.readLine())!=null) {
				contenido = contenido+""+linea+"\n";
			}
			
			textarea.setText(contenido);
		            
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void datos() {
		
		File fichero = new File("archivo.txt");
		SimpleDateFormat formato = new SimpleDateFormat("dd-MM-yyyy - HH:mm:ss");
		
		System.out.println("Nombre del fichero -> "+fichero.getName()+"\nTama�o del fichero -> "+fichero.length()+"\nFecha de modificacion -> "+formato.format(fichero.lastModified())+"\nPermisos -> R: "+fichero.canRead()+" W: "+fichero.canWrite()+" X: "+fichero.canExecute());
		
		
	}

	public void eliminar() {
		File fichero = new File("archivo.txt");
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Confirmation Dialog");
		alert.setHeaderText("Eliminar archivo");
		alert.setContentText("�Seguro que quiere eliminar el archivo?");
		ButtonType si = new ButtonType("SI");
		ButtonType no = new ButtonType("NO");
		
		alert.getButtonTypes().setAll(si,no);

		Optional<ButtonType> result = alert.showAndWait();
		if (result.get() == si){
		    if(fichero.delete()) {
		    	System.out.println("Se ha eliminado el archivo");
		    }
		} else {
		   
		}
	}

}

package application;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public class StaXParser {

	static final String ASIGNATURA = "asignatura";
	static final String CREDITOS = "creditos";
	static final String DESCRIPCION = "descripcion";
	static final String ITEM = "item";

	public List<Item> lecturaArchivo(String archivo) {
		List<Item> listaPersonas = new ArrayList<Item>();

		try {
			XMLInputFactory inputFactory = XMLInputFactory.newInstance();
			InputStream in = new FileInputStream(archivo);
			XMLEventReader eventReader = inputFactory.createXMLEventReader(in);
			

			Item item = null;

			while (eventReader.hasNext()) {
				XMLEvent event = eventReader.nextEvent();

				if (event.isStartElement()) {
					StartElement startElement = event.asStartElement();
					// If we have an item element, we create a new item
					if (startElement.getName().getLocalPart().equals(ITEM)) {
						item = new Item();
					}
					if (event.asStartElement().getName().getLocalPart().equals(ASIGNATURA)) {
						event = eventReader.nextEvent();
						item.setAsignatura(event.asCharacters().getData());
						continue;
					}

					if (event.isStartElement()) {
						if (event.asStartElement().getName().getLocalPart().equals(CREDITOS)) {
							event = eventReader.nextEvent();
							item.setCreditos(event.asCharacters().getData());
							continue;
						}
					}
					if (event.asStartElement().getName().getLocalPart().equals(DESCRIPCION)) {
						event = eventReader.nextEvent();
						item.setDescripcion(event.asCharacters().getData());
						continue;
					}


				}
				// If we reach the end of an item element, we add it to the list
				if (event.isEndElement()) {
					EndElement endElement = event.asEndElement();
					if (endElement.getName().getLocalPart().equals(ITEM)) {
						listaPersonas.add(item);
					}
				}

			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (XMLStreamException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return listaPersonas;

	}


	public void actualizarXML(String archivo, List<Item> listaItems) {

		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = dbf.newDocumentBuilder();
			Document document = documentBuilder.parse(archivo);
			document.getDocumentElement().normalize();

			Node padre = document.getDocumentElement();

			for (Item t : listaItems) {
				Element root = document.createElement("item");
				Node asignatura = document.createElement("asignatura");
				asignatura.setTextContent(t.getAsignatura());
				Node creditos = document.createElement("creditos");
				creditos.setTextContent(t.getCreditos());
				Node descripcion = document.createElement("descripcion");
				descripcion.setTextContent(t.getDescripcion());

				root.appendChild(asignatura);
				root.appendChild(creditos);
				root.appendChild(descripcion);
				padre.appendChild(root);
			}
			
			

			Source source = new DOMSource(document);
			File xmlFile = new File(archivo);
			StreamResult result = new StreamResult(new OutputStreamWriter(new FileOutputStream(xmlFile), "ISO-8859-1"));
			Transformer xformer = TransformerFactory.newInstance().newTransformer();
			xformer.transform(source, result);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}

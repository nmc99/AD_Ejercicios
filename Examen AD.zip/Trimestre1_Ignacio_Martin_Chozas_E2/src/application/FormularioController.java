package application;

import java.util.ArrayList;
import java.util.List;

import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class FormularioController {

	public TextField input_asignatura;
	public TextField input_creditos;
	public TextArea input_descripcion;
	public static List<Item> listaItems = new ArrayList<Item>();
	
	public void grabar() {
		String asignatura = input_asignatura.getText();
		String creditos = input_creditos.getText();
		String descripcion = input_creditos.getText();
		
		Item i = new Item(asignatura,creditos,descripcion);
		listaItems.add(i);
		
		
		StaXParser parser = new StaXParser();
		parser.actualizarXML("archivo.xml", listaItems);
		listaItems.clear();
		
		List<Item> listaItems = new ArrayList<Item>();
		listaItems = parser.lecturaArchivo("archivo.xml");
		for(Item item : listaItems) {
			System.out.println(item.toString());
		}
	}
	
}

package main;
	
import java.util.ArrayList;
import java.util.List;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;


public class Main {
	
	public static void main(String[] args) {
		Json_Parser parser = new Json_Parser();
		List<Item> listaItems = new ArrayList<Item>();
		listaItems = parser.leerJSON("archivo.json");
		for	(Item item : listaItems) {
			System.out.println("Asignatura: "+item.getAsignatura());
			System.out.println("Creditos: "+item.getCreditos());
			System.out.println("\n");
		}
		
		
	}
}

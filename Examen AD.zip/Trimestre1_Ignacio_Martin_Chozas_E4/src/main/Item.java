package main;

public class Item {

	String asignatura,creditos,descripcion;
	
	public Item() {
		super();
	}

	public Item(String asignatura, String creditos, String descripcion) {
		super();
		this.asignatura = asignatura;
		this.creditos = creditos;
		this.descripcion = descripcion;
	}

	public String getAsignatura() {
		return asignatura;
	}

	public void setAsignatura(String asignatura) {
		this.asignatura = asignatura;
	}

	public String getCreditos() {
		return creditos;
	}

	public void setCreditos(String creditos) {
		this.creditos = creditos;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	@Override
	public String toString() {
		return "Item [asignatura=" + asignatura + ", creditos=" + creditos + ", descripcion=" + descripcion + "]";
	}

	
	
	
	
}

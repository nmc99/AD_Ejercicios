package main;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Json_Parser {
	public List<Item> leerJSON(String archivo) {
		List<Item> listaItemsJson = new ArrayList<Item>();

		JSONParser jsonParser = new JSONParser();

		try (FileReader reader = new FileReader(archivo)) {

			Object obj = jsonParser.parse(reader);

			JSONArray listaPersonas = (JSONArray) obj;
			listaPersonas.forEach(item -> parsearItem((JSONObject) item, listaItemsJson));

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return listaItemsJson;
	}

	public static void parsearItem(JSONObject item, List<Item> listaItems) {
		JSONObject i = (JSONObject) item.get("item");
		List<Item> listaFinal = new ArrayList<Item>();

		String asignatura = (String) i.get("asignatura");
		String creditos = (String) i.get("creditos");
		String descripcion = (String) i.get("descripcion");

		Item it = new Item(asignatura, creditos, descripcion);
		listaItems.add(it);
	}

	public void escribirJSON(String archivo, List<Item> listaItems) {
		JSONArray listadoFinal = new JSONArray();

		for (Item p : listaItems) {
			JSONObject detallesPersona = new JSONObject();
			detallesPersona.put("asignatura", p.getAsignatura());
			detallesPersona.put("creditos", p.getCreditos());
			detallesPersona.put("descripcion", p.getDescripcion());

			JSONObject item = new JSONObject();
			item.put("item", detallesPersona);
			listadoFinal.add(item);
		}

		try (FileWriter file = new FileWriter(archivo)) {

			file.write(listadoFinal.toJSONString());
			file.flush();
			System.out.println("Insertado correctamente!");

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String mostrarJSON(String archivo) {
		JSONParser jsonParser = new JSONParser();
		String resultado = "";

		try (FileReader reader = new FileReader(archivo)) {

			Object obj = jsonParser.parse(reader);

			JSONArray listaItems = (JSONArray) obj;
			resultado = listaItems.toJSONString();
			System.out.println(listaItems);
		}catch(Exception e) {
			
		}
		return resultado;
	}
}

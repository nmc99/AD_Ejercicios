import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StaXParser parser = new StaXParser();
		
		ArrayList<Cliente> lista = (ArrayList<Cliente>) parser.leerXML("archivo.xml");
		
		for	(Cliente cliente : lista) {
			System.out.println("Nombre: "+cliente.getNombre()+" Telefono: "+cliente.getTelefono());
		}
		
	}

}
